from ._scholarly import _Scholarly
from ._proxy_generator import ProxyGenerator
from .data_types import Author, Publication
scholarly = _Scholarly()
