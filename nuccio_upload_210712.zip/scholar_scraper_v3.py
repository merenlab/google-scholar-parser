###Imports
import argparse
import csv
from random import *
import re
from scholarly import scholarly #https://scholarly.readthedocs.io/en/latest/quickstart.html
                                #search-for-an-author-by-the-id-visible-in-the-url-of-an-authors-profile
                                #make adjustments with instructions found below:
                                    #https://github.com/scholarly-python-package/scholarly/issues/297
import time
from time import sleep

###Use Argparse to Take In Commandline Arguments
parser = argparse.ArgumentParser()
group = parser.add_mutually_exclusive_group()
group.add_argument("--in_IDs", nargs = "+", help = "One or more IDs entered via the commandline")
group.add_argument("--in_file", help = "File of scholar author IDs entered via the commdline. File should contain one ID per row")
parser.add_argument("--out_file", help = "Output file with publication info in .tsv format")
args = parser.parse_args()

###Extract IDs from Input
author_ids = []
if args.in_IDs:
    author_ids = args.in_IDs
elif args.in_file:
    with open(args.in_file, 'r') as in_f:
        preIdList = [id.strip() for id in in_f]
    author_ids = [id.replace(',', '') for id in preIdList]
else:
    print("You must enter either an author ID or a file containing author IDs")
print(author_ids)

#Retrieve the author's data, fill-in, and print
dicList = []
for a_id in author_ids:
    print('Processing:')
    print(a_id)
    id = scholarly.search_author_id(a_id)
    #print(id)
    #print('\n')

    name = id['name']
    print(name)

    author = scholarly.fill(id) #!!!This is how you fill author by ID!!!
    #print(author)
    #nPub = scholarly.fill(author['publications'][0])
    numPub = len(author['publications'])


    '''Generate random intervals for time between accessing publications
    as means to avoid upsetting Goliath'''

    randList = []
    n = 0
    while n < numPub:
        n = n + 1
        ran = randint(30, 150)
        randList.append(ran)

    ###Gather publication info
    i = 0
    for publication in author['publications']:
        if i < 2: #use for testing purposes
        #if i < len(author['publications']):
            nPub = scholarly.fill(author['publications'][i])
            print(nPub)
            dicList.append(nPub)
            i = i + 1
            print("Printed pub " + str(i))

            t = randList[i]
            print("Sleep for " + str(t) + " seconds")
            time.sleep(t)

#Write to a .tsv file
with open(args.out_file, 'wt') as o_file:
    tsv_writer = csv.writer(o_file, delimiter='\t')
    tsv_writer.writerow(['Title', 'Authors', 'Year', 'Journal', 'Volume', 'Number', 'Pages'])
    for v in dicList:
        title = ''
        auth = ''
        year = ''
        jour = ''
        volu = ''
        numb = ''
        page = ''
        if 'title' in v['bib']:
            title = v['bib']['title']
            print(title)
        else:
            title = 'NA'
        if 'author' in v['bib']:
            auth = v['bib']['author']
        else:
            auth = 'NA'
        if 'pub_year' in v['bib']:
            year = v['bib']['pub_year']
        else:
            year = 'NA'
        if 'journal' in v['bib']:
            jour = v['bib']['journal']
        else:
            jour = 'NA'
        if 'volume' in v['bib']:
            volu = v['bib']['volume']
        else:
            volu = 'NA'
        if 'number' in v['bib']:
            numb = v['bib']['number']
        else:
            numb = 'NA'
        if 'pages' in v['bib']:
            page = v['bib']['pages']
        else:
            page = 'NA'
        tsv_writer.writerow([title, auth, year, jour, volu, numb, page])
